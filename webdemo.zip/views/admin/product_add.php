<h2>Thêm sản phẩm</h2>
<form method="post">
    <input type="text" name="name" placeholder="Tên sản phẩm" required><br>
    <input type="number" name="price" placeholder="Giá" required><br>
    <textarea name="description" placeholder="Mô tả"></textarea><br>
    <button type="submit">Thêm</button>
</form>
